
package part1;
import java.util.Scanner;

class Part1 {
    private Scanner scanner = new Scanner (System.in);
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    
    public boolean checkUsername (){
        if (username.length() > 5 || username.contains("_")) {
            return true;
        } else {
            return false; 
        }
    }
    
    public boolean checkPasswordComplexity() {
        if (password.length() < 8 ) {
            return false;
        }
        if (!password.matches(".*[A-Z]*.")) {
            return false;
        }
        if (!password.matches(".*[0-8]*.")) {
            return false;
        }
        if(!password.matches(".*[!@#$%^&*(),.?'\":{}|<>].*")) {
            return false;
        }
        return true;
    }
    
    public String registerUser() {
        System.out.print("Enter username: ");
        username = scanner.nextLine();
        while (!checkUsername()) {
            System.out.print("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 charecters in length. Enter username: ");
            username = scanner.nextLine();
        }
        
        System.out.print("Enter password: ");
        password = scanner.nextLine();
        while (!checkPasswordComplexity()) {
            System.out.print("Password is not correctly formatted, please ensure that the password contains atleast 8 charecters , a capital letter, a number and a special charecter. Enter password: ");
            password = scanner.nextLine();
        }
        
        System.out.print("Enter first name: ");
        firstName = scanner.nextLine();
        
        System.out.print("Enter last name: ");
        lastName = scanner.nextLine();
        
        return "Regestration successful" ;
     }
    
    public boolean loginUser() {
        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();
        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();
        
        if (loginUsername.equals(username) && loginPassword.equals(password)) {
            System.out.println("Welcome " + firstName + " " + lastName + "! It is great to see you again.");
            return true; 
        } else {
            System.out.println("Username or password incorrect. Please try again.");
            return false; 
        }
    }
    
    public static void main (String [] args ) {
        Part1 part1 = new Part1();
        System.out.println(part1.registerUser());
        part1.loginUser();
    }
    

    } 



//refernce list:
//1.w3schools (2019). Java Tutorial. [online] W3schools.com. Available at: https://www.w3schools.com/java/.
//2. w3Schools (2019). Introduction to Java. [online] W3schools.com. Available at: https://www.w3schools.com/java/java_intro.asp.
//3. www.w3schools.com. (n.d.). Java Examples. [online] Available at: https://www.w3schools.com/java/java_examples.asp.


‌
           

    

