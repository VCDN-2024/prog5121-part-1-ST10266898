
package part1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Part1Test {

    private static void setUsername(String kyl_1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public Part1Test() {
    }
    
    @Test
    public void testUsernameCorrectlyFormatted() {
        Part1Test part1Test = new Part1Test();
        Part1Test.setUsername("kyl_1");
        Assertions.assertTrue(part1Test.checkUsername());
        Assertions.assertEquals("Welcome kyl ,1 it is great to see you.", part1Test.loginUser());
    }

    
     
@Test
    public void testUsernameIncorrectlyFormatted() {
        Part1Test part1Test = new Part1Test();
        Part1Test.setUsername("kyle!!!!!!!21; 22; 23 2023©");
        Assertions.assertFalse(part1Test.checkUsername());
        Assertions.assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.", part1Test.registerUser());
    }
    
    
     @Test
    public void testPasswordComplexity() {
        Part1Test part1Test = new Part1Test();
        part1Test.setPassword("Ch&&sec@ke99!");
        Assertions.assertTrue(part1Test.checkPasswordComplexity());
        Assertions.assertEquals("Password successfully captured", part1Test.registerUser());
    }
    
    @Test
    public void testPasswordNoComplexity() {
        Part1Test part1Test = new Part1Test();
        part1Test.setPassword("password");
        Assertions.assertFalse(part1Test.checkPasswordComplexity());
        Assertions.assertEquals("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.", part1Test.registerUser());
    }

    @Test
    public void testUsernameCorrectFormat() {
        Part1Test part1Test  = new Part1Test();
        part1Test.setUsername("kyl_1");
        Assertions.assertTrue(part1Test.checkUsername());
    }
    
    @Test
    public void testUsernameIncorrectFormat() {
        Part1Test part1Test = new Part1Test();
        part1Test.setUsername("kyle!!!!!!!21; 22; 23 2023©");
        Assertions.assertFalse(part1Test.checkUsername());
    }
    
    @Test
    public void testPasswordComplexityTrue() {
        Part1Test part1Test = new Part1Test();
        part1Test.setPassword("Ch&&sec@ke99!");
        Assertions.assertTrue(part1Test.checkPasswordComplexity());
    }
    
    @Test
    public void testPasswordComplexityFalse() {
        Part1Test part1Test = new Part1Test();
         part1Test.setPassword("password");
        Assertions.assertFalse(part1Test.checkPasswordComplexity());
    }

    
    
    private boolean checkUsername() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Object loginUser() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Object registerUser() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void setPassword(String chsecke99) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean checkPasswordComplexity() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}


//Refernce list:
//1. W3schools. (n.d.). JUnit Tutorial. [online] Available at: https://www.w3schools.blog/junit-tutorial.
//2. BrowserStack. (n.d.). Unit Testing in Java with JUnit. [online] Available at: https://www.browserstack.com/guide/unit-testing-java.
//‌3. freeCodeCamp.org. (2023). How to Write Unit Tests in Java. [online] Available at: https://www.freecodecamp.org/news/java-unit-testing/.

‌